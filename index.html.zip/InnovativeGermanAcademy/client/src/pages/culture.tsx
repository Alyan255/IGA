
import CulturalImmersion from "@/components/culture/cultural-immersion";

export default function Culture() {
  return (
    <div>
      <CulturalImmersion />
    </div>
  );
}
