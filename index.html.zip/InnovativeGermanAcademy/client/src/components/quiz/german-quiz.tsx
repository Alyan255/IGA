import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";

interface Question {
  id: number;
  type: 'listening' | 'speaking' | 'writing' | 'reading';
  question: string;
  options: string[];
  correctAnswer: string;
  level: 'basic' | 'intermediate' | 'proficient';
}

const sampleQuestions: Question[] = [
  {
    id: 1,
    type: 'reading',
    question: 'Was bedeutet "Guten Morgen"?',
    options: ['Good Morning', 'Good Night', 'Good Evening', 'Good Afternoon'],
    correctAnswer: 'Good Morning',
    level: 'basic'
  },
  {
    id: 2,
    type: 'writing',
    question: 'Complete the sentence: "Ich ___ Student."',
    options: ['bin', 'ist', 'sind', 'bist'],
    correctAnswer: 'bin',
    level: 'basic'
  },
  {
    id: 3,
    type: 'reading',
    question: 'Was bedeutet "Danke"?',
    options: ['Hello', 'Please', 'Thank you', 'Sorry'],
    correctAnswer: 'Thank you',
    level: 'basic'
  },
  {
    id: 4,
    type: 'writing',
    question: 'Complete: "Wie ___ du?"',
    options: ['heißt', 'heißen', 'heiße', 'heißest'],
    correctAnswer: 'heißt',
    level: 'basic'
  },
  {
    id: 5,
    type: 'reading',
    question: 'What does "Auf Wiedersehen" mean?',
    options: ['Good morning', 'Hello', 'Goodbye', 'Good night'],
    correctAnswer: 'Goodbye',
    level: 'basic'
  },
  {
    id: 6,
    type: 'writing',
    question: 'Fill in: "Er ___ aus Deutschland."',
    options: ['kommt', 'kommst', 'kommen', 'komme'],
    correctAnswer: 'kommt',
    level: 'basic'
  },
  {
    id: 7,
    type: 'reading',
    question: 'What is "Entschuldigung"?',
    options: ['Excuse me', 'Thank you', 'Please', 'You\'re welcome'],
    correctAnswer: 'Excuse me',
    level: 'basic'
  },
  {
    id: 8,
    type: 'writing',
    question: 'Complete: "Wir ___ Deutsch."',
    options: ['lernen', 'lernt', 'lerne', 'lernst'],
    correctAnswer: 'lernen',
    level: 'basic'
  },
  {
    id: 9,
    type: 'reading',
    question: 'Was bedeutet "Ja"?',
    options: ['No', 'Maybe', 'Yes', 'Sometimes'],
    correctAnswer: 'Yes',
    level: 'basic'
  },
  {
    id: 10,
    type: 'writing',
    question: 'Fill in: "Sie ___ eine Katze."',
    options: ['hat', 'hast', 'haben', 'habe'],
    correctAnswer: 'hat',
    level: 'basic'
  }
];

export default function GermanQuiz() {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<Record<number, string>>({});
  const [showResults, setShowResults] = useState(false);
  const [selectedLevel, setSelectedLevel] = useState<'basic' | 'intermediate' | 'proficient'>('basic');

  const filteredQuestions = sampleQuestions.filter(q => q.level === selectedLevel);

  const handleAnswer = (answer: string) => {
    setAnswers({ ...answers, [currentQuestion]: answer });
  };

  const calculateScore = () => {
    let correct = 0;
    Object.entries(answers).forEach(([questionIndex, answer]) => {
      if (filteredQuestions[parseInt(questionIndex)].correctAnswer === answer) {
        correct++;
      }
    });
    return (correct / filteredQuestions.length) * 100;
  };

  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl font-bold mb-4">German Language Quiz</h2>
          {!showResults && (
            <div className="mb-8">
              <Button
                variant={selectedLevel === 'basic' ? 'default' : 'outline'}
                onClick={() => setSelectedLevel('basic')}
                className="mx-2"
              >
                Basic (50 Questions)
              </Button>
              <Button
                variant={selectedLevel === 'intermediate' ? 'default' : 'outline'}
                onClick={() => setSelectedLevel('intermediate')}
                className="mx-2"
              >
                Intermediate (100 Questions)
              </Button>
              <Button
                variant={selectedLevel === 'proficient' ? 'default' : 'outline'}
                onClick={() => setSelectedLevel('proficient')}
                className="mx-2"
              >
                Proficient (150 Questions)
              </Button>
            </div>
          )}
        </motion.div>

        {!showResults ? (
          <Card className="max-w-2xl mx-auto">
            <CardContent className="p-8">
              <h3 className="text-xl font-bold mb-4">
                Question {currentQuestion + 1} of {filteredQuestions.length}
              </h3>
              <p className="text-gray-600 mb-6">
                {filteredQuestions[currentQuestion]?.question}
              </p>
              <RadioGroup
                onValueChange={handleAnswer}
                value={answers[currentQuestion]}
                className="space-y-4"
              >
                {filteredQuestions[currentQuestion]?.options.map((option, index) => (
                  <div key={index} className="flex items-center">
                    <RadioGroupItem value={option} id={`option-${index}`} />
                    <Label className="ml-2" htmlFor={`option-${index}`}>
                      {option}
                    </Label>
                  </div>
                ))}
              </RadioGroup>
              <div className="mt-8 flex justify-between">
                <Button
                  onClick={() => setCurrentQuestion(prev => Math.max(0, prev - 1))}
                  disabled={currentQuestion === 0}
                >
                  Previous
                </Button>
                <Button
                  onClick={() => {
                    if (currentQuestion === filteredQuestions.length - 1) {
                      setShowResults(true);
                    } else {
                      setCurrentQuestion(prev => prev + 1);
                    }
                  }}
                >
                  {currentQuestion === filteredQuestions.length - 1 ? 'Finish' : 'Next'}
                </Button>
              </div>
            </CardContent>
          </Card>
        ) : (
          <Card className="max-w-2xl mx-auto">
            <CardContent className="p-8 text-center">
              <h3 className="text-2xl font-bold mb-4">Quiz Results</h3>
              <p className="text-xl mb-4">Your Score: {calculateScore().toFixed(1)}%</p>
              <Button
                onClick={() => {
                  setShowResults(false);
                  setCurrentQuestion(0);
                  setAnswers({});
                }}
              >
                Try Again
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </section>
  );
}