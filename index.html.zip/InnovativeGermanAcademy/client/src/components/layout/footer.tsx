import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faFlag } from "@fortawesome/free-solid-svg-icons";

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-white py-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-lg font-bold mb-4">Contact Us</h3>
            <p>Email: info@innovativegerman.com</p>
            <p>Phone: +92-349-8660326</p>
            <p>Address: Main Boulevard, Lahore, Pakistan</p>
          </div>

          <div>
            <h3 className="text-lg font-bold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li><a href="/courses" className="hover:text-primary">Courses</a></li>
              <li><a href="/registration" className="hover:text-primary">Register</a></li>
            </ul>
          </div>

          <div className="flex items-center justify-center space-x-4">
            {/* German Flag */}
            <div className="w-12 h-8 flex flex-col border border-gray-600">
              <div className="flex-1 bg-black"></div>
              <div className="flex-1 bg-[#DD0000]"></div>
              <div className="flex-1 bg-[#FFCE00]"></div>
            </div>

            {/* Pakistani Flag */}
            <div className="relative w-12 h-8 border border-gray-600">
              <div className="absolute inset-0 bg-[#01411C]"></div>
              <div className="absolute left-0 top-0 bottom-0 w-1/4 bg-white"></div>
              <div className="absolute left-1/4 inset-y-0 right-0 flex items-center justify-center">
                <div className="w-5 h-5 rounded-full bg-white"></div>
                <div className="absolute w-4.5 h-4.5 rounded-full transform translate-x-0.5 -translate-y-0.5">
                  <div className="w-full h-full rounded-full bg-[#01411C]"></div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-8 text-center text-gray-400">
          <p>&copy; 2024 Innovative German Academy. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}