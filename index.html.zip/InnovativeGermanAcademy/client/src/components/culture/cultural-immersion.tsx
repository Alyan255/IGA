
import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";

const culturalImages = [
  {
    url: "https://images.unsplash.com/photo-1467269204594-9661b134dd2b",
    title: "Cologne Cathedral",
    location: "Cologne",
    description: "Gothic masterpiece and UNESCO World Heritage site"
  },
  {
    url: "https://images.unsplash.com/photo-1599946347371-68eb71b16afc",
    title: "Neuschwanstein Castle",
    location: "Bavaria",
    description: "A 19th-century Romanesque Revival palace"
  },
  {
    url: "https://images.unsplash.com/photo-1587330979470-3595ac045ab0",
    title: "Brandenburg Gate",
    location: "Berlin",
    description: "An 18th-century neoclassical monument"
  },
  {
    url: "https://images.unsplash.com/photo-1560969184-10fe8719e047",
    title: "Heidelberg Castle",
    location: "Heidelberg",
    description: "Renaissance period castle ruins overlooking the Neckar River"
  },
  {
    url: "https://images.unsplash.com/photo-1566404791232-af9fe0ae8f8b",
    title: "Berlin Cathedral",
    location: "Berlin",
    description: "Supreme Parish and Collegiate Church"
  }
];

export default function CulturalImmersion() {
  const [currentImage, setCurrentImage] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentImage((prev) => (prev + 1) % culturalImages.length);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  return (
    <section className="py-16 bg-gradient-to-b from-white to-gray-50">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-12">
          Cultural Immersion
        </h2>

        <div className="mb-16">
          <h3 className="text-2xl font-bold text-center mb-8">Discover Germany's Rich Heritage</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5 }}
            >
              <Card>
                <CardContent className="p-6">
                  <h4 className="text-xl font-bold mb-4">Historical Legacy</h4>
                  <p className="text-gray-600">Germany's rich history spans over two millennia, from Roman times through the Holy Roman Empire to the modern era. Experience the architectural marvels, cultural traditions, and historical significance that shape modern Germany.</p>
                </CardContent>
              </Card>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <Card>
                <CardContent className="p-6">
                  <h4 className="text-xl font-bold mb-4">Cultural Excellence</h4>
                  <p className="text-gray-600">From classical music to contemporary art, German culture has influenced the world. Discover the land of poets, thinkers, and innovators while immersing yourself in a society that values tradition and progress equally.</p>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1 }}
            className="relative h-[500px] rounded-lg overflow-hidden"
          >
            <AnimatePresence mode="wait">
              <motion.div
                key={currentImage}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.5 }}
                className="absolute inset-0"
              >
                <img
                  src={culturalImages[currentImage].url}
                  alt={culturalImages[currentImage].title}
                  className="w-full h-full object-cover"
                />
                <div className="absolute bottom-0 left-0 right-0 bg-black/50 text-white p-4">
                  <h3 className="text-xl font-bold">
                    {culturalImages[currentImage].title}
                  </h3>
                  <p className="text-sm">
                    {culturalImages[currentImage].location} - {culturalImages[currentImage].description}
                  </p>
                </div>
              </motion.div>
            </AnimatePresence>
          </motion.div>

          <div className="space-y-6">
            <Card>
              <CardContent className="p-6">
                <h3 className="text-xl font-bold mb-4">Experience German Heritage</h3>
                <p className="text-gray-600">
                  Immerse yourself in Germany's rich cultural heritage spanning over two millennia. From historic landmarks to modern innovations, discover the essence of German society through our comprehensive cultural program.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <h3 className="text-xl font-bold mb-4">Cultural Activities</h3>
                <ul className="list-disc pl-4 space-y-2 text-gray-600">
                  <li>Virtual tours of German museums and landmarks</li>
                  <li>German film screenings and discussions</li>
                  <li>Traditional festival celebrations</li>
                  <li>Language exchange meetups</li>
                  <li>German cuisine workshops</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}
