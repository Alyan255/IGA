import { Card } from "@/components/ui/card";
import { motion } from "framer-motion";
import { useState } from "react";

const landmarks = [
  {
    city: "Berlin",
    name: "Brandenburg Gate",
    image: "https://images.unsplash.com/photo-1674321516263-377d83f3279a",
    description: "An 18th-century neoclassical monument in Berlin, a symbol of German unity and peace."
  },
  {
    city: "Cologne",
    name: "Cologne Cathedral",
    image: "https://images.unsplash.com/photo-1674321517207-d08a4923d5cc",
    description: "A magnificent Gothic cathedral and UNESCO World Heritage site, took over 600 years to complete."
  },
  {
    city: "Hamburg",
    name: "Elbphilharmonie",
    image: "https://images.unsplash.com/photo-1717397326226-d710badeb95d",
    description: "A modern architectural marvel combining concert halls, hotel, and residential apartments."
  },
  {
    city: "Munich",
    name: "Marienplatz",
    image: "https://images.unsplash.com/photo-1595867818082-083862f3d630",
    description: "The central square of Munich featuring the New Town Hall with its famous Glockenspiel."
  },
  {
    city: "Heidelberg",
    name: "Heidelberg Castle",
    image: "https://images.unsplash.com/photo-1501435676753-5c3a47b9dd1f",
    description: "Renaissance castle ruins overlooking the city, a symbol of German Romanticism."
  }
];

export default function Map() {
  const [selectedLandmark, setSelectedLandmark] = useState<number>(0);

  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-12">
          Discover Germany's Rich Heritage
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5 }}
            className="relative h-[500px] rounded-lg overflow-hidden"
          >
            <img
              src={landmarks[selectedLandmark].image}
              alt={landmarks[selectedLandmark].name}
              className="w-full h-full object-cover"
            />
            <div className="absolute bottom-0 left-0 right-0 bg-black/50 text-white p-6">
              <h3 className="text-2xl font-bold mb-2">{landmarks[selectedLandmark].name}</h3>
              <p className="text-lg mb-2">{landmarks[selectedLandmark].city}</p>
              <p>{landmarks[selectedLandmark].description}</p>
            </div>
          </motion.div>

          <div className="grid grid-cols-1 gap-4">
            {landmarks.map((landmark, index) => (
              <motion.div
                key={landmark.city}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <Card
                  className={`cursor-pointer transition-all p-4 ${
                    selectedLandmark === index
                      ? "border-primary border-2"
                      : "hover:border-primary"
                  }`}
                  onClick={() => setSelectedLandmark(index)}
                >
                  <h3 className="font-bold text-lg">{landmark.name}</h3>
                  <p className="text-gray-600">{landmark.city}</p>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}