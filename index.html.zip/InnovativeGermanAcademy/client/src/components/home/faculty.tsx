import { Card, CardContent } from "@/components/ui/card";
import { motion } from "framer-motion";

const faculty = [
  {
    name: "Dr. Mueller",
    role: "Senior German Instructor",
    image: "https://images.unsplash.com/photo-1558402989-4778474384c9",
    bio: "20+ years of teaching experience"
  },
  {
    name: "Prof. Schmidt",
    role: "Language Coordinator",
    image: "https://images.unsplash.com/photo-1556157382-97eda2d62296",
    bio: "Expert in German linguistics"
  },
  {
    name: "Ms. Weber",
    role: "Cultural Studies Expert",
    image: "https://images.unsplash.com/photo-1700616270842-0e14a8c42004",
    bio: "Specializes in German culture and traditions"
  }
];

export default function Faculty() {
  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-12">
          Meet Our Faculty
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {faculty.map((member, index) => (
            <motion.div
              key={member.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.2 }}
            >
              <Card>
                <CardContent className="p-6">
                  <img
                    src={member.image}
                    alt={member.name}
                    className="w-32 h-32 rounded-full mx-auto mb-4 object-cover"
                  />
                  <h3 className="text-xl font-bold text-center mb-2">
                    {member.name}
                  </h3>
                  <p className="text-primary text-center mb-2">{member.role}</p>
                  <p className="text-gray-600 text-center">{member.bio}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
